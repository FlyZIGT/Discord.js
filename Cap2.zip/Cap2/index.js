const Discord = require('discord.js');
const client = new Discord.Client();

//set prefix

prefix = "!"

client.on('ready', () => {
	console.log(`Logged in as ${client.user.tag}!`); 
	client.user.setPresence({ activity: { name: 'Siendo un bot' }, status: 'dnd'})
});


client.on('message', message => {

	if(message.content.startsWith (prefix + "ping")) {
		message.channel.send("Pong!")
	}

	if(message.content.startsWith (prefix + "bonzi")) {
		message.channel.send("https://media.discordapp.net/attachments/864824588667977728/865619937011564565/BonziSunglasses_1.gif")
	}
});

client.login("token") 
