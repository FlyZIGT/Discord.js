const Discord = require("discord.js");
const client = new Discord.Client();
const { Client, MessageEmbed } = require("discord.js");

module.exports = {
	name: 'bonzi',  // Nombre de nuestro comando.
	description: 'Bonzi!!', // Una descripción
	execute(message, args) {
		// Aquí iran todas las funciones que haga nuestro bot.

		message.channel.send("https://media.discordapp.net/attachments/864824588667977728/865619937011564565/BonziSunglasses_1.gif")
	
	

	}, 
};
