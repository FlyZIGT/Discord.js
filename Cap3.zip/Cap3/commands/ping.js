const Discord = require("discord.js");
const client = new Discord.Client();
const { Client, MessageEmbed } = require("discord.js");

module.exports = {
	name: 'ping',  // Nombre de nuestro comando.
	description: 'Ping!', // Una descripción
	execute(message, args) {
		// Aquí iran todas las funciones que haga nuestro bot.

		message.channel.send("Pong!")
		message.channel.send("Ping!, Pong!")
	
	

	}, 
};
