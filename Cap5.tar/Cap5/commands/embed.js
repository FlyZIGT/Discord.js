const Discord = require("discord.js");
const client = new Discord.Client();
const { Client, MessageEmbed } = require("discord.js");

module.exports = {
	name: 'embed',  // Nombre de nuestro comando.
	description: 'Un nuevo embed', // Una descripción
	execute(message, args) {

        const embed = new Discord.MessageEmbed()
    .setTitle("Embed")
    .setAuthor(message.author.username, message.author.displayAvatarURL())
    .setColor(0x5c8560)
    .setDescription("Mi nuevo embed :D")
    .setFooter("Prueba")
    .setImage("https://cdn.discordapp.com/attachments/865683555799138326/867150785937408010/images.png")
    .setThumbnail("https://cdn.discordapp.com/attachments/865683555799138326/867150785937408010/images.png")
    .setTimestamp()
    .setURL("https://discord.js.org/")
	





    message.channel.send(embed)


	}, 
};