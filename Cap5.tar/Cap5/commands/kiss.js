const Discord = require("discord.js");
const client = new Discord.Client();
const { Client, MessageEmbed } = require("discord.js");

module.exports = {
	name: 'kiss',  // Nombre de nuestro comando.
	description: 'Besa a alguien.', // Una descripción
	execute(message, args) {

	let user = message.mentions.members.first();


	
	
	//VARIABLES
	
	
	var besos = ['https://images-ext-1.discordapp.net/external/pJ8sv9j74I2pZ0xU8-IlaihvExO-2eSLd_uRyoRGQlg/https/nekocdn.com/images/8JfApwdl.gif', 'https://media.discordapp.net/attachments/399448944889036801/706990103834394634/1533441670_Matsuri_kiss_Yuzu_Gif.gif', 'https://images-ext-2.discordapp.net/external/ZajY8RhHKexfuVSbo4u3kHRxjLwlJoPvPKPet9DzI0I/https/nekocdn.com/images/2vHncA0r.gif']

	var aleatorio = Math.floor(Math.random()*(besos.length));

	//EMBED


	 var beso1 = new Discord.MessageEmbed()
	.setDescription(`${message.author} Le ha dado un beso a ${user}`)
	.setColor("RANDOM")
	.setImage(besos[aleatorio])



	if(!user) return message.channel.send("❌ |  Debes mencionar a un usuario >.<").then(msg => msg.delete({timeout: 3000}))

	message.channel.send(beso1)
	}, 
};